# CheckTheFacts
Check the facts CBS project

As of now, this project is in progress. The code is not complete and doesn't portray what the outcome will be. Parts of the code are mixed between my own and what I found online from other projects that will inspire the layout. They will be cited and explained on a later date, when the project is complete. There will be an update soon. 
